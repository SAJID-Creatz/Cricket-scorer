package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.entity.BallEntity
import com.example.data.local.entity.InningsEntity
import com.example.data.local.entity.MatchEntity
import com.example.data.local.entity.PlayerEntity
import com.example.data.repository.CricketRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class CricketViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: CricketRepository

    init {
        val dao = AppDatabase.getDatabase(application).cricketDao()
        repository = CricketRepository(dao)

        viewModelScope.launch {
            repository.checkAndSeedInitialData()
        }
    }

    val matches: StateFlow<List<MatchEntity>> = repository.allMatches
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val players: StateFlow<List<PlayerEntity>> = repository.allPlayers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedMatchId = MutableStateFlow<Long?>(1L)
    val selectedMatchId: StateFlow<Long?> = _selectedMatchId.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val selectedMatch: StateFlow<MatchEntity?> = _selectedMatchId
        .flatMapLatest { id ->
            if (id != null) repository.getMatchFlow(id) else flowOf(null)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    @OptIn(ExperimentalCoroutinesApi::class)
    val selectedMatchInnings: StateFlow<List<InningsEntity>> = _selectedMatchId
        .flatMapLatest { id ->
            if (id != null) repository.getInningsForMatchFlow(id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val selectedMatchBalls: StateFlow<List<BallEntity>> = _selectedMatchId
        .flatMapLatest { id ->
            if (id != null) repository.getBallsForMatchFlow(id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectMatch(matchId: Long) {
        _selectedMatchId.value = matchId
    }

    fun scoreBall(
        runs: Int,
        isWide: Boolean = false,
        isNoBall: Boolean = false,
        isBye: Boolean = false,
        isLegBye: Boolean = false,
        isWicket: Boolean = false,
        wicketType: String? = null,
        dismissedPlayerName: String? = null,
        fielderName: String? = null,
        nextBatsmanName: String? = null
    ) {
        val matchId = _selectedMatchId.value ?: return
        viewModelScope.launch {
            repository.scoreBall(
                matchId = matchId,
                runs = runs,
                isWide = isWide,
                isNoBall = isNoBall,
                isBye = isBye,
                isLegBye = isLegBye,
                isWicket = isWicket,
                wicketType = wicketType,
                dismissedPlayerName = dismissedPlayerName,
                fielderName = fielderName,
                nextBatsmanName = nextBatsmanName
            )
        }
    }

    fun undoLastBall() {
        val matchId = _selectedMatchId.value ?: return
        viewModelScope.launch {
            repository.undoLastBall(matchId)
        }
    }

    fun switchStriker() {
        val matchId = _selectedMatchId.value ?: return
        viewModelScope.launch {
            repository.switchStriker(matchId)
        }
    }

    fun changeBowler(newBowlerName: String) {
        val matchId = _selectedMatchId.value ?: return
        viewModelScope.launch {
            repository.changeBowler(matchId, newBowlerName)
        }
    }

    fun createMatch(
        teamA: String,
        teamB: String,
        venue: String,
        totalOvers: Int,
        ballType: String,
        tossWinner: String,
        tossDecision: String,
        strikerName: String,
        nonStrikerName: String,
        bowlerName: String,
        onCreated: (Long) -> Unit
    ) {
        viewModelScope.launch {
            val matchId = repository.createNewMatch(
                teamA = teamA,
                teamB = teamB,
                venue = venue,
                totalOvers = totalOvers,
                ballType = ballType,
                tossWinner = tossWinner,
                tossDecision = tossDecision,
                strikerName = strikerName,
                nonStrikerName = nonStrikerName,
                bowlerName = bowlerName
            )
            _selectedMatchId.value = matchId
            onCreated(matchId)
        }
    }
}
