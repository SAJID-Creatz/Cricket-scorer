package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BoundaryBlue
import com.example.ui.theme.PitchAmberAccent
import com.example.ui.theme.StadiumGreenPrimary
import com.example.ui.theme.WicketCrimson

@Composable
fun ScoringKeypad(
    onScoreRun: (Int) -> Unit,
    onScoreWide: () -> Unit,
    onScoreNoBall: () -> Unit,
    onScoreBye: (Int) -> Unit,
    onScoreLegBye: (Int) -> Unit,
    onWicketClick: () -> Unit,
    onUndoClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.95f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Section Title & Undo Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SCORE CONSOLE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 1.sp
                )

                OutlinedButton(
                    onClick = onUndoClick,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.height(32.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Undo,
                        contentDescription = "Undo",
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Undo Ball", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Runs row: 0, 1, 2, 3, 4, 6
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                RunKeyButton(label = "0", bgColor = Color(0xFF334155), onClick = { onScoreRun(0) })
                RunKeyButton(label = "1", bgColor = StadiumGreenPrimary, onClick = { onScoreRun(1) })
                RunKeyButton(label = "2", bgColor = StadiumGreenPrimary, onClick = { onScoreRun(2) })
                RunKeyButton(label = "3", bgColor = StadiumGreenPrimary, onClick = { onScoreRun(3) })
                RunKeyButton(label = "4", bgColor = BoundaryBlue, onClick = { onScoreRun(4) })
                RunKeyButton(label = "6", bgColor = PitchAmberAccent, textColor = Color.Black, onClick = { onScoreRun(6) })
            }

            // Extras & Wicket row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ExtraKeyButton(label = "WD", subtitle = "Wide", bgColor = Color(0xFF8B5CF6), onClick = onScoreWide, modifier = Modifier.weight(1f))
                ExtraKeyButton(label = "NB", subtitle = "No Ball", bgColor = Color(0xFFF97316), onClick = onScoreNoBall, modifier = Modifier.weight(1f))
                ExtraKeyButton(label = "BYE", subtitle = "1 Bye", bgColor = Color(0xFF64748B), onClick = { onScoreBye(1) }, modifier = Modifier.weight(1f))
                ExtraKeyButton(label = "LB", subtitle = "1 Leg Bye", bgColor = Color(0xFF64748B), onClick = { onScoreLegBye(1) }, modifier = Modifier.weight(1f))
                
                // Wicket Big Button
                Box(
                    modifier = Modifier
                        .weight(1.2f)
                        .height(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(WicketCrimson)
                        .clickable { onWicketClick() }
                        .padding(horizontal = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "WICKET",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                }
            }
        }
    }
}

@Composable
private fun RunKeyButton(
    label: String,
    bgColor: Color,
    textColor: Color = Color.White,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(bgColor)
            .border(1.dp, Color.White.copy(alpha = 0.2f), CircleShape)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 18.sp,
            fontWeight = FontWeight.ExtraBold,
            color = textColor
        )
    }
}

@Composable
private fun ExtraKeyButton(
    label: String,
    subtitle: String,
    bgColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .height(48.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(bgColor)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = subtitle,
                fontSize = 9.sp,
                color = Color.White.copy(alpha = 0.8f)
            )
        }
    }
}
