package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.PlayerEntity
import com.example.ui.theme.PitchAmberAccent
import com.example.ui.theme.StadiumGreenLight
import com.example.ui.theme.WicketCrimson

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayersScreen(
    players: List<PlayerEntity>
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedPlayerForModal by remember { mutableStateOf<PlayerEntity?>(null) }

    val tabs = listOf("Top Runs", "Top Wickets", "Most 6s", "High Scores")

    val filteredPlayers = remember(players, searchQuery, selectedTab) {
        val base = players.filter {
            it.name.contains(searchQuery, ignoreCase = true) ||
            it.teamName.contains(searchQuery, ignoreCase = true)
        }

        when (selectedTab) {
            0 -> base.sortedByDescending { it.runsScored }
            1 -> base.sortedByDescending { it.wicketsTaken }
            2 -> base.sortedByDescending { it.sixesCount }
            3 -> base.sortedByDescending { it.highestScore }
            else -> base
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Player Statistics & Leaderboard", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Search Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search player or team...") },
                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = "Search") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            // Category Filter Chips
            ScrollableTabRow(selectedTabIndex = selectedTab, edgePadding = 16.dp) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Players List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                items(filteredPlayers) { player ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedPlayerForModal = player },
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                                    modifier = Modifier.size(42.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = player.name.take(1),
                                            fontWeight = FontWeight.ExtraBold,
                                            color = MaterialTheme.colorScheme.primary,
                                            fontSize = 16.sp
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column {
                                    Text(
                                        text = player.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                    Text(
                                        text = "${player.teamName} • ${player.role}",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            // Stat Badge
                            Column(horizontalAlignment = Alignment.End) {
                                when (selectedTab) {
                                    0 -> {
                                        Text("${player.runsScored} runs", fontWeight = FontWeight.ExtraBold, color = StadiumGreenLight)
                                        Text("SR: %.1f".format(player.strikeRate), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    1 -> {
                                        Text("${player.wicketsTaken} wkts", fontWeight = FontWeight.ExtraBold, color = WicketCrimson)
                                        Text("Econ: %.2f".format(player.bowlingEconomy), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    2 -> {
                                        Text("${player.sixesCount} sixes", fontWeight = FontWeight.ExtraBold, color = PitchAmberAccent)
                                        Text("${player.foursCount} fours", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    3 -> {
                                        Text("HS: ${player.highestScore}", fontWeight = FontWeight.ExtraBold, color = StadiumGreenLight)
                                        Text("Runs: ${player.runsScored}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Detailed Player Profile Dialog
    if (selectedPlayerForModal != null) {
        val p = selectedPlayerForModal!!
        AlertDialog(
            onDismissRequest = { selectedPlayerForModal = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Leaderboard, contentDescription = null, tint = StadiumGreenLight)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(p.name, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(text = "Team: ${p.teamName} (${p.role})", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    HorizontalDivider()

                    Text(text = "BATTING STATS", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = StadiumGreenLight)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Matches: ${p.matchesPlayed}", fontSize = 12.sp)
                        Text("Runs: ${p.runsScored}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("High Score: ${p.highestScore}", fontSize = 12.sp)
                        Text("Strike Rate: %.1f".format(p.strikeRate), fontSize = 12.sp)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("4s: ${p.foursCount} | 6s: ${p.sixesCount}", fontSize = 12.sp)
                        Text("50s: ${p.fifties} | 100s: ${p.hundreds}", fontSize = 12.sp)
                    }

                    HorizontalDivider()
                    Text(text = "BOWLING STATS", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = PitchAmberAccent)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Wickets: ${p.wicketsTaken}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("Economy: %.2f".format(p.bowlingEconomy), fontSize = 12.sp)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Overs: ${p.ballsBowled / 6}.${p.ballsBowled % 6}", fontSize = 12.sp)
                        Text("Maidens: ${p.maidensCount}", fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedPlayerForModal = null }) {
                    Text("Close")
                }
            }
        )
    }
}
