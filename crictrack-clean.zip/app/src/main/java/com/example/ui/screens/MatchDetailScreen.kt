package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.SportsCricket
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.BallEntity
import com.example.data.local.entity.InningsEntity
import com.example.data.local.entity.MatchEntity
import com.example.ui.components.BallCircle
import com.example.ui.theme.PitchAmberAccent
import com.example.ui.theme.StadiumGreenLight
import com.example.ui.theme.WicketCrimson

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MatchDetailScreen(
    match: MatchEntity?,
    inningsList: List<InningsEntity>,
    balls: List<BallEntity>,
    onOpenLiveConsole: (Long) -> Unit,
    onBackClick: () -> Unit
) {
    if (match == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabs = listOf("Summary", "Scorecard", "Commentary")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "${match.teamA} vs ${match.teamB}", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (match.status == "LIVE") {
                        TextButton(onClick = { onOpenLiveConsole(match.id) }) {
                            Icon(imageVector = Icons.Default.SportsCricket, contentDescription = null, tint = StadiumGreenLight, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Live Console", fontWeight = FontWeight.Bold, color = StadiumGreenLight)
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Header Match Result Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(text = match.venue, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(6.dp))

                    inningsList.forEach { inn ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = inn.battingTeam,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = "${inn.totalRuns}/${inn.totalWickets} (${inn.totalOversCount}.${inn.ballsInCurrentOver} ov)",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 15.sp,
                                color = StadiumGreenLight
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                    }

                    if (!match.winnerMessage.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = match.winnerMessage,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = PitchAmberAccent
                        )
                    }
                }
            }

            // Tab Row
            TabRow(selectedTabIndex = selectedTabIndex) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = { Text(title, fontWeight = FontWeight.Bold) }
                    )
                }
            }

            // Tab Content
            when (selectedTabIndex) {
                0 -> MatchSummaryTab(match = match, inningsList = inningsList)
                1 -> FullScorecardTab(inningsList = inningsList, balls = balls)
                2 -> CommentaryTab(balls = balls)
            }
        }
    }
}

@Composable
private fun MatchSummaryTab(
    match: MatchEntity,
    inningsList: List<InningsEntity>
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "TOSS & MATCH DETAILS", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "Toss: ${match.tossWinner} elected to ${match.tossDecision.lowercase()}", fontSize = 13.sp)
                    Text(text = "Format: ${match.totalOvers} Overs • ${match.ballType} Ball", fontSize = 13.sp)
                    Text(text = "Venue: ${match.venue}", fontSize = 13.sp)
                }
            }
        }

        items(inningsList) { inn ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "INNINGS ${inn.inningsNumber} - ${inn.battingTeam.uppercase()}",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp,
                        color = StadiumGreenLight
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Total Score:", fontWeight = FontWeight.Medium)
                        Text(text = "${inn.totalRuns}/${inn.totalWickets} in ${inn.totalOversCount}.${inn.ballsInCurrentOver} overs", fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Extras:", fontWeight = FontWeight.Medium)
                        Text(text = "${inn.wides + inn.noBalls + inn.byes + inn.legByes} (Wd ${inn.wides}, NB ${inn.noBalls}, B ${inn.byes}, LB ${inn.legByes})", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun FullScorecardTab(
    inningsList: List<InningsEntity>,
    balls: List<BallEntity>
) {
    var selectedInningsNum by remember { mutableIntStateOf(1) }

    Column(modifier = Modifier.fillMaxSize()) {
        if (inningsList.size > 1) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                inningsList.forEach { inn ->
                    FilterChip(
                        selected = selectedInningsNum == inn.inningsNumber,
                        onClick = { selectedInningsNum = inn.inningsNumber },
                        label = { Text("Innings ${inn.inningsNumber} (${inn.battingTeam})") },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        val inningsBalls = balls.filter { it.inningsNumber == selectedInningsNum }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = "BATTING SCORECARD",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.sp,
                    color = StadiumGreenLight
                )
            }

            // Group balls by batsman to compile scorecard
            val batsmanStats = inningsBalls.groupBy { it.batsmanName }.map { (name, bList) ->
                val runs = bList.filter { !it.isWide && !it.isBye && !it.isLegBye }.sumOf { it.runs }
                val ballsFaced = bList.count { !it.isWide }
                val fours = bList.count { !it.isWide && !it.isBye && !it.isLegBye && it.runs == 4 }
                val sixes = bList.count { !it.isWide && !it.isBye && !it.isLegBye && it.runs == 6 }
                val isOut = inningsBalls.any { it.isWicket && it.dismissedPlayerName == name }
                ScorecardBatter(name, runs, ballsFaced, fours, sixes, isOut)
            }

            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Batter", fontWeight = FontWeight.Bold, modifier = Modifier.weight(2f), fontSize = 12.sp)
                            Text("R", fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.6f), fontSize = 12.sp)
                            Text("B", fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.6f), fontSize = 12.sp)
                            Text("4s", fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.6f), fontSize = 12.sp)
                            Text("6s", fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.6f), fontSize = 12.sp)
                            Text("SR", fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.8f), fontSize = 12.sp)
                        }
                        HorizontalDivider()

                        batsmanStats.forEach { b ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(2f)) {
                                    Text(
                                        text = b.name + if (!b.isOut) "*" else "",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = if (!b.isOut) StadiumGreenLight else MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = if (b.isOut) "out" else "not out",
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text("${b.runs}", fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.6f), fontSize = 13.sp)
                                Text("${b.balls}", modifier = Modifier.weight(0.6f), fontSize = 12.sp)
                                Text("${b.fours}", modifier = Modifier.weight(0.6f), fontSize = 12.sp)
                                Text("${b.sixes}", modifier = Modifier.weight(0.6f), fontSize = 12.sp)
                                val sr = if (b.balls > 0) (b.runs.toDouble() / b.balls) * 100 else 0.0
                                Text("%.1f".format(sr), modifier = Modifier.weight(0.8f), fontSize = 11.sp, fontWeight = FontWeight.Medium)
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                        }
                    }
                }
            }

            item {
                Text(
                    text = "BOWLING SCORECARD",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.sp,
                    color = StadiumGreenLight
                )
            }

            // Group balls by bowler
            val bowlerStats = inningsBalls.groupBy { it.bowlerName }.map { (name, bList) ->
                val validBalls = bList.count { !it.isWide && !it.isNoBall }
                val runsConceded = bList.sumOf {
                    if (it.isBye || it.isLegBye) 0 else it.runs + (if (it.isWide || it.isNoBall) 1 else 0)
                }
                val wickets = bList.count { it.isWicket }
                ScorecardBowler(name, validBalls, runsConceded, wickets)
            }

            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Bowler", fontWeight = FontWeight.Bold, modifier = Modifier.weight(2f), fontSize = 12.sp)
                            Text("O", fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.6f), fontSize = 12.sp)
                            Text("R", fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.6f), fontSize = 12.sp)
                            Text("W", fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.6f), fontSize = 12.sp)
                            Text("Econ", fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.8f), fontSize = 12.sp)
                        }
                        HorizontalDivider()

                        bowlerStats.forEach { bw ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(bw.name, fontWeight = FontWeight.Bold, modifier = Modifier.weight(2f), fontSize = 13.sp)
                                val oversStr = "${bw.validBalls / 6}.${bw.validBalls % 6}"
                                Text(oversStr, modifier = Modifier.weight(0.6f), fontSize = 12.sp)
                                Text("${bw.runsConceded}", modifier = Modifier.weight(0.6f), fontSize = 12.sp)
                                Text("${bw.wickets}", fontWeight = FontWeight.Bold, color = WicketCrimson, modifier = Modifier.weight(0.6f), fontSize = 13.sp)
                                val econ = if (bw.validBalls > 0) (bw.runsConceded.toDouble() / bw.validBalls) * 6 else 0.0
                                Text("%.2f".format(econ), modifier = Modifier.weight(0.8f), fontSize = 11.sp)
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CommentaryTab(balls: List<BallEntity>) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        reverseLayout = true
    ) {
        items(balls.reversed()) { ball ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BallCircle(ball = ball)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = ball.commentary,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

private data class ScorecardBatter(
    val name: String,
    val runs: Int,
    val balls: Int,
    val fours: Int,
    val sixes: Int,
    val isOut: Boolean
)

private data class ScorecardBowler(
    val name: String,
    val validBalls: Int,
    val runsConceded: Int,
    val wickets: Int
)
