package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val StadiumGreenPrimary = Color(0xFF059669)
val StadiumGreenLight = Color(0xFF10B981)
val DeepNavyDark = Color(0xFF0F172A)
val CardNavySurface = Color(0xFF1E293B)
val PitchAmberAccent = Color(0xFFF59E0B)
val WicketCrimson = Color(0xFFEF4444)
val BoundaryBlue = Color(0xFF2563EB)

val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val DarkBackground = Color(0xFF090D16)
val DarkSurface = Color(0xFF131C2E)

