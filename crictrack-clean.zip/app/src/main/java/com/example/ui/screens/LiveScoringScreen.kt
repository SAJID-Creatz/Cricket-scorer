package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.BallEntity
import com.example.data.local.entity.InningsEntity
import com.example.data.local.entity.MatchEntity
import com.example.ui.components.BallCircle
import com.example.ui.components.LiveScoreCardBanner
import com.example.ui.components.ScoringKeypad
import com.example.ui.theme.PitchAmberAccent
import com.example.ui.theme.StadiumGreenLight
import com.example.ui.theme.WicketCrimson

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiveScoringScreen(
    match: MatchEntity?,
    inningsList: List<InningsEntity>,
    balls: List<BallEntity>,
    onScoreRun: (Int) -> Unit,
    onScoreWide: () -> Unit,
    onScoreNoBall: () -> Unit,
    onScoreBye: (Int) -> Unit,
    onScoreLegBye: (Int) -> Unit,
    onWicket: (wicketType: String, outPlayer: String, fielder: String, newBatsman: String) -> Unit,
    onUndoClick: () -> Unit,
    onSwitchStriker: () -> Unit,
    onChangeBowler: (String) -> Unit,
    onOpenFullScorecard: (Long) -> Unit,
    onBackClick: () -> Unit
) {
    if (match == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    val currentInnings = inningsList.firstOrNull { it.inningsNumber == match.currentInnings }
    val currentInningsBalls = balls.filter { it.inningsNumber == match.currentInnings }
    
    // Wicket Dialog state
    var showWicketDialog by remember { mutableStateOf(false) }
    var selectedWicketType by remember { mutableStateOf("Bowled") }
    var outPlayerName by remember { mutableStateOf(match.currentStrikerName) }
    var fielderName by remember { mutableStateOf("") }
    var newBatsmanName by remember { mutableStateOf("") }

    // Change Bowler Dialog state
    var showChangeBowlerDialog by remember { mutableStateOf(false) }
    var newBowlerInput by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "${match.teamA} vs ${match.teamB}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Live Console • ${match.venue}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { onOpenFullScorecard(match.id) }) {
                        Icon(imageVector = Icons.Default.ListAlt, contentDescription = "Scorecard", tint = StadiumGreenLight)
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Live Score Banner Card
            LiveScoreCardBanner(
                match = match,
                currentInnings = currentInnings,
                onSwitchStriker = onSwitchStriker,
                onChangeBowlerClick = {
                    newBowlerInput = ""
                    showChangeBowlerDialog = true
                }
            )

            // Current Over Timeline Bar
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "THIS OVER:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(10.dp))

                    val thisOverBalls = if (currentInnings != null) {
                        currentInningsBalls.filter { it.overNumber == currentInnings.totalOversCount }
                    } else emptyList()

                    if (thisOverBalls.isEmpty()) {
                        Text(
                            text = "Over started...",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                        )
                    } else {
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            items(thisOverBalls) { ball ->
                                BallCircle(ball = ball)
                            }
                        }
                    }
                }
            }

            // Ball Commentary Feed
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    reverseLayout = true
                ) {
                    items(currentInningsBalls.reversed()) { ball ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                BallCircle(ball = ball)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = ball.commentary,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }
                }
            }

            // Scoring Keypad
            ScoringKeypad(
                onScoreRun = onScoreRun,
                onScoreWide = onScoreWide,
                onScoreNoBall = onScoreNoBall,
                onScoreBye = onScoreBye,
                onScoreLegBye = onScoreLegBye,
                onWicketClick = {
                    outPlayerName = match.currentStrikerName
                    fielderName = ""
                    newBatsmanName = ""
                    showWicketDialog = true
                },
                onUndoClick = onUndoClick
            )
        }
    }

    // Wicket Dialog
    if (showWicketDialog) {
        AlertDialog(
            onDismissRequest = { showWicketDialog = false },
            title = {
                Text(
                    text = "FALL OF WICKET",
                    fontWeight = FontWeight.Bold,
                    color = WicketCrimson
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(text = "Select Wicket Type:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    val wicketTypes = listOf("Bowled", "Caught", "LBW", "Run Out", "Stumped")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        wicketTypes.take(3).forEach { type ->
                            FilterChip(
                                selected = selectedWicketType == type,
                                onClick = { selectedWicketType = type },
                                label = { Text(type, fontSize = 10.sp) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        wicketTypes.drop(3).forEach { type ->
                            FilterChip(
                                selected = selectedWicketType == type,
                                onClick = { selectedWicketType = type },
                                label = { Text(type, fontSize = 10.sp) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    OutlinedTextField(
                        value = outPlayerName,
                        onValueChange = { outPlayerName = it },
                        label = { Text("Dismissed Batsman") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    if (selectedWicketType == "Caught" || selectedWicketType == "Run Out" || selectedWicketType == "Stumped") {
                        OutlinedTextField(
                            value = fielderName,
                            onValueChange = { fielderName = it },
                            label = { Text("Fielder / Wicket Keeper Name") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }

                    OutlinedTextField(
                        value = newBatsmanName,
                        onValueChange = { newBatsmanName = it },
                        label = { Text("New Batsman Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onWicket(selectedWicketType, outPlayerName, fielderName, newBatsmanName)
                        showWicketDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = WicketCrimson)
                ) {
                    Text("Confirm Wicket")
                }
            },
            dismissButton = {
                TextButton(onClick = { showWicketDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Change Bowler Dialog
    if (showChangeBowlerDialog) {
        AlertDialog(
            onDismissRequest = { showChangeBowlerDialog = false },
            title = {
                Text("Change Bowler", fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Enter name of the next bowler:", fontSize = 12.sp)
                    OutlinedTextField(
                        value = newBowlerInput,
                        onValueChange = { newBowlerInput = it },
                        label = { Text("Bowler Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newBowlerInput.isNotBlank()) {
                            onChangeBowler(newBowlerInput)
                        }
                        showChangeBowlerDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StadiumGreenLight)
                ) {
                    Text("Set Bowler")
                }
            },
            dismissButton = {
                TextButton(onClick = { showChangeBowlerDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
