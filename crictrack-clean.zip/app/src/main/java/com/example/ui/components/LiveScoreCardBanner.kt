package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.SportsCricket
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.InningsEntity
import com.example.data.local.entity.MatchEntity
import com.example.ui.theme.PitchAmberAccent
import com.example.ui.theme.StadiumGreenLight
import com.example.ui.theme.WicketCrimson

@Composable
fun LiveScoreCardBanner(
    match: MatchEntity,
    currentInnings: InningsEntity?,
    onSwitchStriker: () -> Unit,
    onChangeBowlerClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Match Header / Venue / Overs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.SportsCricket,
                        contentDescription = "Cricket",
                        tint = StadiumGreenLight,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${match.teamA} vs ${match.teamB}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Text(
                        text = "${match.totalOvers} Overs • ${match.ballType}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Main Score & Overs
            if (currentInnings != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column {
                        Text(
                            text = currentInnings.battingTeam.uppercase(),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = StadiumGreenLight,
                            letterSpacing = 1.sp
                        )
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = "${currentInnings.totalRuns}/${currentInnings.totalWickets}",
                                fontSize = 36.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "(${currentInnings.totalOversCount}.${currentInnings.ballsInCurrentOver}/${match.totalOvers} ov)",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(bottom = 6.dp)
                            )
                        }
                    }

                    // Run Rates
                    Column(horizontalAlignment = Alignment.End) {
                        val totalBalls = (currentInnings.totalOversCount * 6) + currentInnings.ballsInCurrentOver
                        val crr = if (totalBalls > 0) (currentInnings.totalRuns.toDouble() / totalBalls) * 6 else 0.0
                        Text(
                            text = "CRR: %.2f".format(crr),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = PitchAmberAccent
                        )
                        if (match.currentInnings == 2 && match.targetRuns != null) {
                            val runsNeeded = match.targetRuns - currentInnings.totalRuns
                            val ballsLeft = (match.totalOvers * 6) - totalBalls
                            val rrr = if (ballsLeft > 0 && runsNeeded > 0) (runsNeeded.toDouble() / ballsLeft) * 6 else 0.0
                            Text(
                                text = "RRR: %.2f".format(rrr),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = WicketCrimson
                            )
                        }
                    }
                }

                // Target Banner if 2nd innings
                if (match.currentInnings == 2 && match.targetRuns != null) {
                    val runsNeeded = match.targetRuns - currentInnings.totalRuns
                    val ballsLeft = (match.totalOvers * 6) - ((currentInnings.totalOversCount * 6) + currentInnings.ballsInCurrentOver)
                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(PitchAmberAccent.copy(alpha = 0.15f))
                            .border(1.dp, PitchAmberAccent.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = if (runsNeeded > 0 && ballsLeft > 0) {
                                "${currentInnings.battingTeam} need $runsNeeded runs in $ballsLeft balls to win"
                            } else if (runsNeeded <= 0) {
                                "${currentInnings.battingTeam} won the match!"
                            } else {
                                "Innings completed."
                            },
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = PitchAmberAccent
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f))
            Spacer(modifier = Modifier.height(12.dp))

            // Active Batsmen & Bowler
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Batsmen column
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "BATSMEN",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        IconButton(
                            onClick = onSwitchStriker,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.SwapHoriz,
                                contentDescription = "Switch Strike",
                                tint = StadiumGreenLight,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "🏏 ${match.currentStrikerName.ifBlank { "Striker" }}*",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = StadiumGreenLight
                    )
                    Text(
                        text = "   ${match.currentNonStrikerName.ifBlank { "Non-Striker" }}",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Bowler column
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "BOWLER",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        TextButton(
                            onClick = onChangeBowlerClick,
                            contentPadding = PaddingValues(0.dp),
                            modifier = Modifier.height(24.dp)
                        ) {
                            Text(
                                text = "Change",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = StadiumGreenLight
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "🎳 ${match.currentBowlerName.ifBlank { "Bowler" }}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}
