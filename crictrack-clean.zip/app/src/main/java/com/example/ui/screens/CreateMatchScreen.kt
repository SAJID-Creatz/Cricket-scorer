package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.StadiumGreenLight

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateMatchScreen(
    onCreateMatch: (
        teamA: String,
        teamB: String,
        venue: String,
        totalOvers: Int,
        ballType: String,
        tossWinner: String,
        tossDecision: String,
        strikerName: String,
        nonStrikerName: String,
        bowlerName: String
    ) -> Unit,
    onBackClick: () -> Unit
) {
    var teamA by remember { mutableStateOf("Royal Strikers") }
    var teamB by remember { mutableStateOf("Super Kings") }
    var venue by remember { mutableStateOf("National Cricket Ground") }
    var totalOversStr by remember { mutableStateOf("20") }
    var ballType by remember { mutableStateOf("Leather") }
    var tossWinnerChoice by remember { mutableStateOf(0) } // 0 -> Team A, 1 -> Team B
    var tossDecision by remember { mutableStateOf("Bat") }
    var strikerName by remember { mutableStateOf("Virat Sharma") }
    var nonStrikerName by remember { mutableStateOf("Rohit Verma") }
    var bowlerName by remember { mutableStateOf("Deepak Chahar") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Setup New Match", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Teams Input Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(text = "TEAMS & VENUE", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = StadiumGreenLight)

                    OutlinedTextField(
                        value = teamA,
                        onValueChange = { teamA = it },
                        label = { Text("Team 1 Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = teamB,
                        onValueChange = { teamB = it },
                        label = { Text("Team 2 Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = venue,
                        onValueChange = { venue = it },
                        label = { Text("Match Venue / Ground") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            }

            // Match Format Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(text = "MATCH FORMAT", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = StadiumGreenLight)

                    Text(text = "Select Overs:", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    val overOptions = listOf("5", "10", "20")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        overOptions.forEach { option ->
                            FilterChip(
                                selected = totalOversStr == option,
                                onClick = { totalOversStr = option },
                                label = { Text("$option Overs", fontSize = 12.sp) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Text(text = "Ball Type:", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    val ballTypeOptions = listOf("Leather", "Tennis", "Windball")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ballTypeOptions.forEach { option ->
                            FilterChip(
                                selected = ballType == option,
                                onClick = { ballType = option },
                                label = { Text(option, fontSize = 12.sp) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Toss Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(text = "TOSS DETAILS", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = StadiumGreenLight)

                    Text(text = "Toss Winner:", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = tossWinnerChoice == 0,
                            onClick = { tossWinnerChoice = 0 },
                            label = { Text(teamA.ifBlank { "Team 1" }) },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = tossWinnerChoice == 1,
                            onClick = { tossWinnerChoice = 1 },
                            label = { Text(teamB.ifBlank { "Team 2" }) },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Text(text = "Elected to:", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = tossDecision == "Bat",
                            onClick = { tossDecision = "Bat" },
                            label = { Text("Bat First") },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = tossDecision == "Bowl",
                            onClick = { tossDecision = "Bowl" },
                            label = { Text("Bowl First") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Initial Players
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(text = "OPENING PLAYERS", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = StadiumGreenLight)

                    OutlinedTextField(
                        value = strikerName,
                        onValueChange = { strikerName = it },
                        label = { Text("Opening Striker") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = nonStrikerName,
                        onValueChange = { nonStrikerName = it },
                        label = { Text("Opening Non-Striker") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = bowlerName,
                        onValueChange = { bowlerName = it },
                        label = { Text("Opening Bowler") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            }

            // Start Match Button
            Button(
                onClick = {
                    val totalOvers = totalOversStr.toIntOrNull() ?: 20
                    val tossWinner = if (tossWinnerChoice == 0) teamA else teamB
                    onCreateMatch(
                        teamA,
                        teamB,
                        venue,
                        totalOvers,
                        ballType,
                        tossWinner,
                        tossDecision,
                        strikerName,
                        nonStrikerName,
                        bowlerName
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = StadiumGreenLight)
            ) {
                Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "Start Scoring Match", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
