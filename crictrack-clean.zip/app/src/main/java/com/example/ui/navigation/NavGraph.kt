package com.example.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material.icons.filled.SportsCricket
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.*
import com.example.ui.theme.StadiumGreenLight
import com.example.viewmodel.CricketViewModel

sealed class Screen(val route: String, val title: String, val icon: @Composable () -> Unit) {
    object Home : Screen("home", "Matches", { Icon(Icons.Default.Home, contentDescription = "Home") })
    object LiveConsole : Screen("live_console", "Live Scorer", { Icon(Icons.Default.SportsCricket, contentDescription = "Live") })
    object CreateMatch : Screen("create_match", "New Match", { Icon(Icons.Default.AddCircle, contentDescription = "New Match") })
    object Players : Screen("players", "Stats", { Icon(Icons.Default.Leaderboard, contentDescription = "Players") })
    object MatchDetail : Screen("match_detail", "Scorecard", { Icon(Icons.Default.SportsCricket, contentDescription = "Scorecard") })
}

@Composable
fun MainAppNavigation(viewModel: CricketViewModel) {
    val navController = rememberNavController()

    val matches by viewModel.matches.collectAsState()
    val players by viewModel.players.collectAsState()
    val selectedMatch by viewModel.selectedMatch.collectAsState()
    val selectedInnings by viewModel.selectedMatchInnings.collectAsState()
    val selectedBalls by viewModel.selectedMatchBalls.collectAsState()

    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    Scaffold(
        bottomBar = {
            if (currentRoute in listOf(Screen.Home.route, Screen.LiveConsole.route, Screen.CreateMatch.route, Screen.Players.route)) {
                NavigationBar {
                    val bottomItems = listOf(Screen.Home, Screen.LiveConsole, Screen.CreateMatch, Screen.Players)
                    bottomItems.forEach { screen ->
                        NavigationBarItem(
                            selected = currentRoute == screen.route,
                            onClick = {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = screen.icon,
                            label = { Text(screen.title) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = StadiumGreenLight,
                                selectedTextColor = StadiumGreenLight
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    matches = matches,
                    topPlayers = players,
                    onSelectMatch = { matchId ->
                        viewModel.selectMatch(matchId)
                        navController.navigate(Screen.MatchDetail.route)
                    },
                    onOpenLiveConsole = { matchId ->
                        viewModel.selectMatch(matchId)
                        navController.navigate(Screen.LiveConsole.route)
                    },
                    onCreateMatchClick = {
                        navController.navigate(Screen.CreateMatch.route)
                    },
                    onViewAllPlayersClick = {
                        navController.navigate(Screen.Players.route)
                    }
                )
            }

            composable(Screen.LiveConsole.route) {
                LiveScoringScreen(
                    match = selectedMatch,
                    inningsList = selectedInnings,
                    balls = selectedBalls,
                    onScoreRun = { runs -> viewModel.scoreBall(runs = runs) },
                    onScoreWide = { viewModel.scoreBall(runs = 0, isWide = true) },
                    onScoreNoBall = { viewModel.scoreBall(runs = 0, isNoBall = true) },
                    onScoreBye = { runs -> viewModel.scoreBall(runs = runs, isBye = true) },
                    onScoreLegBye = { runs -> viewModel.scoreBall(runs = runs, isLegBye = true) },
                    onWicket = { wicketType, outPlayer, fielder, newBatsman ->
                        viewModel.scoreBall(
                            runs = 0,
                            isWicket = true,
                            wicketType = wicketType,
                            dismissedPlayerName = outPlayer,
                            fielderName = fielder,
                            nextBatsmanName = newBatsman
                        )
                    },
                    onUndoClick = { viewModel.undoLastBall() },
                    onSwitchStriker = { viewModel.switchStriker() },
                    onChangeBowler = { bowler -> viewModel.changeBowler(bowler) },
                    onOpenFullScorecard = { matchId ->
                        viewModel.selectMatch(matchId)
                        navController.navigate(Screen.MatchDetail.route)
                    },
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(Screen.CreateMatch.route) {
                CreateMatchScreen(
                    onCreateMatch = { teamA, teamB, venue, overs, ballType, tossWinner, tossDecision, striker, nonStriker, bowler ->
                        viewModel.createMatch(
                            teamA, teamB, venue, overs, ballType, tossWinner, tossDecision, striker, nonStriker, bowler
                        ) { newMatchId ->
                            navController.navigate(Screen.LiveConsole.route) {
                                popUpTo(Screen.Home.route)
                            }
                        }
                    },
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(Screen.Players.route) {
                PlayersScreen(players = players)
            }

            composable(Screen.MatchDetail.route) {
                MatchDetailScreen(
                    match = selectedMatch,
                    inningsList = selectedInnings,
                    balls = selectedBalls,
                    onOpenLiveConsole = { matchId ->
                        viewModel.selectMatch(matchId)
                        navController.navigate(Screen.LiveConsole.route)
                    },
                    onBackClick = { navController.popBackStack() }
                )
            }
        }
    }
}
