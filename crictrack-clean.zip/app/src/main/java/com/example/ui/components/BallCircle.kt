package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.BallEntity
import com.example.ui.theme.BoundaryBlue
import com.example.ui.theme.PitchAmberAccent
import com.example.ui.theme.StadiumGreenPrimary
import com.example.ui.theme.WicketCrimson

@Composable
fun BallCircle(
    ball: BallEntity,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, label) = when {
        ball.isWicket -> Triple(WicketCrimson, Color.White, "W")
        ball.runs == 6 -> Triple(PitchAmberAccent, Color.Black, "6")
        ball.runs == 4 -> Triple(BoundaryBlue, Color.White, "4")
        ball.isWide -> Triple(Color(0xFF8B5CF6), Color.White, "${ball.runs + 1}Wd")
        ball.isNoBall -> Triple(Color(0xFFF97316), Color.White, "${ball.runs + 1}NB")
        ball.isBye -> Triple(Color(0xFF64748B), Color.White, "${ball.runs}B")
        ball.isLegBye -> Triple(Color(0xFF64748B), Color.White, "${ball.runs}LB")
        ball.runs == 0 -> Triple(Color(0xFF334155), Color.White, "0")
        else -> Triple(StadiumGreenPrimary, Color.White, "${ball.runs}")
    }

    Box(
        modifier = modifier
            .size(34.dp)
            .clip(CircleShape)
            .background(bgColor)
            .border(1.dp, Color.White.copy(alpha = 0.2f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = textColor,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
