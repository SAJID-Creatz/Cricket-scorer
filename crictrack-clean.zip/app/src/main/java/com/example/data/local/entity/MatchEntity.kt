package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "matches")
data class MatchEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val teamA: String,
    val teamB: String,
    val venue: String,
    val totalOvers: Int,
    val ballType: String, // Leather, Tennis
    val tossWinner: String,
    val tossDecision: String, // Bat, Bowl
    val status: String, // LIVE, COMPLETED, UPCOMING
    val currentInnings: Int = 1,
    val targetRuns: Int? = null,
    val winnerMessage: String? = null,
    val currentStrikerName: String = "",
    val currentNonStrikerName: String = "",
    val currentBowlerName: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
