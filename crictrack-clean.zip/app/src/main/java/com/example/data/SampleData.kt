package com.example.data

import com.example.data.local.entity.BallEntity
import com.example.data.local.entity.InningsEntity
import com.example.data.local.entity.MatchEntity
import com.example.data.local.entity.PlayerEntity

object SampleData {

    val samplePlayers = listOf(
        // Royal Strikers
        PlayerEntity(name = "Virat Sharma", teamName = "Royal Strikers", role = "Batter", matchesPlayed = 18, runsScored = 642, ballsFaced = 420, highestScore = 92, foursCount = 58, sixesCount = 24, fifties = 5, hundreds = 0, wicketsTaken = 2, runsConceded = 45, ballsBowled = 24),
        PlayerEntity(name = "Rohit Verma", teamName = "Royal Strikers", role = "Batter", matchesPlayed = 16, runsScored = 510, ballsFaced = 340, highestScore = 88, foursCount = 46, sixesCount = 22, fifties = 4, hundreds = 0),
        PlayerEntity(name = "KL Rahul", teamName = "Royal Strikers", role = "Wicket Keeper", matchesPlayed = 15, runsScored = 420, ballsFaced = 310, highestScore = 74, foursCount = 38, sixesCount = 14, fifties = 3),
        PlayerEntity(name = "Suryakumar Yadav", teamName = "Royal Strikers", role = "Batter", matchesPlayed = 14, runsScored = 480, ballsFaced = 260, highestScore = 81, foursCount = 42, sixesCount = 31, fifties = 4),
        PlayerEntity(name = "Hardik Pandya", teamName = "Royal Strikers", role = "All-Rounder", matchesPlayed = 17, runsScored = 380, ballsFaced = 220, highestScore = 65, foursCount = 28, sixesCount = 25, fifties = 2, wicketsTaken = 19, runsConceded = 380, ballsBowled = 240, maidensCount = 2),
        PlayerEntity(name = "Jasprit Bumrah", teamName = "Royal Strikers", role = "Bowler", matchesPlayed = 18, runsScored = 45, ballsFaced = 35, highestScore = 16, foursCount = 4, sixesCount = 1, wicketsTaken = 31, runsConceded = 320, ballsBowled = 360, maidensCount = 8),
        PlayerEntity(name = "Kuldeep Yadav", teamName = "Royal Strikers", role = "Bowler", matchesPlayed = 12, runsScored = 20, ballsFaced = 18, highestScore = 10, wicketsTaken = 18, runsConceded = 240, ballsBowled = 216, maidensCount = 3),
        
        // Super Kings
        PlayerEntity(name = "MS Dhoni", teamName = "Super Kings", role = "Wicket Keeper", matchesPlayed = 20, runsScored = 580, ballsFaced = 380, highestScore = 76, foursCount = 40, sixesCount = 32, fifties = 4),
        PlayerEntity(name = "Ruturaj Gaikwad", teamName = "Super Kings", role = "Batter", matchesPlayed = 17, runsScored = 590, ballsFaced = 410, highestScore = 98, foursCount = 54, sixesCount = 20, fifties = 5),
        PlayerEntity(name = "Ravindra Jadeja", teamName = "Super Kings", role = "All-Rounder", matchesPlayed = 19, runsScored = 310, ballsFaced = 200, highestScore = 52, foursCount = 22, sixesCount = 16, fifties = 1, wicketsTaken = 22, runsConceded = 390, ballsBowled = 312, maidensCount = 4),
        PlayerEntity(name = "Shivam Dube", teamName = "Super Kings", role = "Batter", matchesPlayed = 15, runsScored = 410, ballsFaced = 250, highestScore = 68, foursCount = 26, sixesCount = 28, fifties = 3),
        PlayerEntity(name = "Deepak Chahar", teamName = "Super Kings", role = "Bowler", matchesPlayed = 14, runsScored = 85, ballsFaced = 50, highestScore = 28, foursCount = 8, sixesCount = 4, wicketsTaken = 20, runsConceded = 310, ballsBowled = 252, maidensCount = 3),
        PlayerEntity(name = "Matheesha Pathirana", teamName = "Super Kings", role = "Bowler", matchesPlayed = 11, runsScored = 10, ballsFaced = 12, highestScore = 6, wicketsTaken = 17, runsConceded = 230, ballsBowled = 198, maidensCount = 2)
    )

    fun getSampleLiveMatch(): MatchEntity {
        return MatchEntity(
            id = 1,
            teamA = "Royal Strikers",
            teamB = "Super Kings",
            venue = "Wankhede Cricket Stadium, Mumbai",
            totalOvers = 20,
            ballType = "Leather",
            tossWinner = "Royal Strikers",
            tossDecision = "Bat",
            status = "LIVE",
            currentInnings = 2,
            targetRuns = 176,
            currentStrikerName = "MS Dhoni",
            currentNonStrikerName = "Ravindra Jadeja",
            currentBowlerName = "Jasprit Bumrah"
        )
    }

    fun getSampleLiveInnings(): List<InningsEntity> {
        return listOf(
            InningsEntity(
                id = 1,
                matchId = 1,
                inningsNumber = 1,
                battingTeam = "Royal Strikers",
                bowlingTeam = "Super Kings",
                totalRuns = 175,
                totalWickets = 5,
                totalOversCount = 20,
                ballsInCurrentOver = 0,
                wides = 6,
                noBalls = 1,
                byes = 2,
                legByes = 4,
                isCompleted = true
            ),
            InningsEntity(
                id = 2,
                matchId = 1,
                inningsNumber = 2,
                battingTeam = "Super Kings",
                bowlingTeam = "Royal Strikers",
                totalRuns = 142,
                totalWickets = 4,
                totalOversCount = 16,
                ballsInCurrentOver = 4,
                wides = 4,
                noBalls = 2,
                byes = 1,
                legByes = 3,
                isCompleted = false
            )
        )
    }

    fun getSampleLiveBalls(): List<BallEntity> {
        return listOf(
            BallEntity(matchId = 1, inningsNumber = 2, overNumber = 16, ballNumberInOver = 1, batsmanName = "MS Dhoni", bowlerName = "Jasprit Bumrah", runs = 1, commentary = "16.1 Bumrah to Dhoni, 1 run, guided down to third man."),
            BallEntity(matchId = 1, inningsNumber = 2, overNumber = 16, ballNumberInOver = 2, batsmanName = "Ravindra Jadeja", bowlerName = "Jasprit Bumrah", runs = 4, commentary = "16.2 Bumrah to Jadeja, FOUR! Slashed over backward point! Magnificent shot!"),
            BallEntity(matchId = 1, inningsNumber = 2, overNumber = 16, ballNumberInOver = 3, batsmanName = "Ravindra Jadeja", bowlerName = "Jasprit Bumrah", runs = 0, commentary = "16.3 Bumrah to Jadeja, no run, yorker on middle, jammed out safely."),
            BallEntity(matchId = 1, inningsNumber = 2, overNumber = 16, ballNumberInOver = 4, batsmanName = "Ravindra Jadeja", bowlerName = "Jasprit Bumrah", runs = 6, commentary = "16.4 Bumrah to Jadeja, SIX! High and handsome over deep midwicket!")
        )
    }

    fun getSampleCompletedMatch(): MatchEntity {
        return MatchEntity(
            id = 2,
            teamA = "Delhi Daredevils",
            teamB = "Kolkata Knights",
            venue = "Eden Gardens, Kolkata",
            totalOvers = 10,
            ballType = "Tennis",
            tossWinner = "Kolkata Knights",
            tossDecision = "Bowl",
            status = "COMPLETED",
            currentInnings = 2,
            targetRuns = 105,
            winnerMessage = "Kolkata Knights won by 6 wickets (with 4 balls remaining)",
            createdAt = System.currentTimeMillis() - 86400000
        )
    }

    fun getSampleCompletedInnings(): List<InningsEntity> {
        return listOf(
            InningsEntity(
                id = 3,
                matchId = 2,
                inningsNumber = 1,
                battingTeam = "Delhi Daredevils",
                bowlingTeam = "Kolkata Knights",
                totalRuns = 104,
                totalWickets = 6,
                totalOversCount = 10,
                ballsInCurrentOver = 0,
                wides = 3,
                noBalls = 1,
                isCompleted = true
            ),
            InningsEntity(
                id = 4,
                matchId = 2,
                inningsNumber = 2,
                battingTeam = "Kolkata Knights",
                bowlingTeam = "Delhi Daredevils",
                totalRuns = 108,
                totalWickets = 4,
                totalOversCount = 9,
                ballsInCurrentOver = 2,
                wides = 5,
                noBalls = 0,
                isCompleted = true
            )
        )
    }
}
