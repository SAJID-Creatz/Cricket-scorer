package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "players")
data class PlayerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val teamName: String,
    val role: String, // Batter, Bowler, All-Rounder, Wicket Keeper
    val matchesPlayed: Int = 0,
    val runsScored: Int = 0,
    val ballsFaced: Int = 0,
    val highestScore: Int = 0,
    val foursCount: Int = 0,
    val sixesCount: Int = 0,
    val fifties: Int = 0,
    val hundreds: Int = 0,
    val wicketsTaken: Int = 0,
    val runsConceded: Int = 0,
    val ballsBowled: Int = 0,
    val maidensCount: Int = 0
) {
    val battingAverage: Double
        get() = if (matchesPlayed > 0) runsScored.toDouble() / matchesPlayed else 0.0

    val strikeRate: Double
        get() = if (ballsFaced > 0) (runsScored.toDouble() / ballsFaced) * 100 else 0.0

    val bowlingEconomy: Double
        get() = if (ballsBowled > 0) (runsConceded.toDouble() / (ballsBowled / 6.0)) else 0.0
}
