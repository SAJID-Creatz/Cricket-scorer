package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.BallEntity
import com.example.data.local.entity.InningsEntity
import com.example.data.local.entity.MatchEntity
import com.example.data.local.entity.PlayerEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CricketDao {

    // Matches
    @Query("SELECT * FROM matches ORDER BY createdAt DESC")
    fun getAllMatches(): Flow<List<MatchEntity>>

    @Query("SELECT * FROM matches WHERE id = :matchId LIMIT 1")
    fun getMatchByIdFlow(matchId: Long): Flow<MatchEntity?>

    @Query("SELECT * FROM matches WHERE id = :matchId LIMIT 1")
    suspend fun getMatchById(matchId: Long): MatchEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMatch(match: MatchEntity): Long

    @Update
    suspend fun updateMatch(match: MatchEntity)

    @Query("DELETE FROM matches WHERE id = :matchId")
    suspend fun deleteMatch(matchId: Long)

    // Innings
    @Query("SELECT * FROM innings WHERE matchId = :matchId ORDER BY inningsNumber ASC")
    fun getInningsForMatchFlow(matchId: Long): Flow<List<InningsEntity>>

    @Query("SELECT * FROM innings WHERE matchId = :matchId AND inningsNumber = :inningsNum LIMIT 1")
    suspend fun getInnings(matchId: Long, inningsNum: Int): InningsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInnings(innings: InningsEntity): Long

    @Update
    suspend fun updateInnings(innings: InningsEntity)

    // Balls
    @Query("SELECT * FROM balls WHERE matchId = :matchId ORDER BY id ASC")
    fun getBallsForMatchFlow(matchId: Long): Flow<List<BallEntity>>

    @Query("SELECT * FROM balls WHERE matchId = :matchId AND inningsNumber = :inningsNum ORDER BY id ASC")
    fun getBallsForInningsFlow(matchId: Long, inningsNum: Int): Flow<List<BallEntity>>

    @Query("SELECT * FROM balls WHERE matchId = :matchId AND inningsNumber = :inningsNum ORDER BY id ASC")
    suspend fun getBallsForInnings(matchId: Long, inningsNum: Int): List<BallEntity>

    @Query("SELECT * FROM balls WHERE matchId = :matchId ORDER BY id DESC LIMIT 1")
    suspend fun getLastBallForMatch(matchId: Long): BallEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBall(ball: BallEntity): Long

    @Query("DELETE FROM balls WHERE id = :ballId")
    suspend fun deleteBallById(ballId: Long)

    // Players
    @Query("SELECT * FROM players ORDER BY runsScored DESC")
    fun getAllPlayersFlow(): Flow<List<PlayerEntity>>

    @Query("SELECT * FROM players WHERE teamName = :teamName")
    suspend fun getPlayersForTeam(teamName: String): List<PlayerEntity>

    @Query("SELECT * FROM players WHERE name = :name LIMIT 1")
    suspend fun getPlayerByName(name: String): PlayerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlayer(player: PlayerEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlayers(players: List<PlayerEntity>)

    @Update
    suspend fun updatePlayer(player: PlayerEntity)
}
