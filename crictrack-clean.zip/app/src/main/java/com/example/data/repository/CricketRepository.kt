package com.example.data.repository

import com.example.data.SampleData
import com.example.data.local.dao.CricketDao
import com.example.data.local.entity.BallEntity
import com.example.data.local.entity.InningsEntity
import com.example.data.local.entity.MatchEntity
import com.example.data.local.entity.PlayerEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class CricketRepository(private val dao: CricketDao) {

    val allMatches: Flow<List<MatchEntity>> = dao.getAllMatches()
    val allPlayers: Flow<List<PlayerEntity>> = dao.getAllPlayersFlow()

    suspend fun checkAndSeedInitialData() {
        val matches = dao.getAllMatches().first()
        if (matches.isEmpty()) {
            // Seed Players
            dao.insertPlayers(SampleData.samplePlayers)

            // Seed Live Match
            val liveMatch = SampleData.getSampleLiveMatch()
            val matchId = dao.insertMatch(liveMatch)
            
            SampleData.getSampleLiveInnings().forEach { inn ->
                dao.insertInnings(inn.copy(matchId = matchId))
            }

            SampleData.getSampleLiveBalls().forEach { ball ->
                dao.insertBall(ball.copy(matchId = matchId))
            }

            // Seed Completed Match
            val compMatch = SampleData.getSampleCompletedMatch()
            val compMatchId = dao.insertMatch(compMatch)

            SampleData.getSampleCompletedInnings().forEach { inn ->
                dao.insertInnings(inn.copy(matchId = compMatchId))
            }
        }
    }

    fun getMatchFlow(matchId: Long): Flow<MatchEntity?> = dao.getMatchByIdFlow(matchId)
    fun getInningsForMatchFlow(matchId: Long): Flow<List<InningsEntity>> = dao.getInningsForMatchFlow(matchId)
    fun getBallsForMatchFlow(matchId: Long): Flow<List<BallEntity>> = dao.getBallsForMatchFlow(matchId)

    suspend fun getMatch(matchId: Long): MatchEntity? = dao.getMatchById(matchId)

    suspend fun createNewMatch(
        teamA: String,
        teamB: String,
        venue: String,
        totalOvers: Int,
        ballType: String,
        tossWinner: String,
        tossDecision: String,
        strikerName: String,
        nonStrikerName: String,
        bowlerName: String
    ): Long {
        val battingTeam = if ((tossWinner == teamA && tossDecision == "Bat") || (tossWinner == teamB && tossDecision == "Bowl")) teamA else teamB
        val bowlingTeam = if (battingTeam == teamA) teamB else teamA

        val match = MatchEntity(
            teamA = teamA,
            teamB = teamB,
            venue = venue,
            totalOvers = totalOvers,
            ballType = ballType,
            tossWinner = tossWinner,
            tossDecision = tossDecision,
            status = "LIVE",
            currentInnings = 1,
            currentStrikerName = strikerName.ifBlank { "Batsman 1" },
            currentNonStrikerName = nonStrikerName.ifBlank { "Batsman 2" },
            currentBowlerName = bowlerName.ifBlank { "Bowler 1" }
        )

        val matchId = dao.insertMatch(match)

        val firstInnings = InningsEntity(
            matchId = matchId,
            inningsNumber = 1,
            battingTeam = battingTeam,
            bowlingTeam = bowlingTeam
        )
        dao.insertInnings(firstInnings)

        // Ensure players exist in player DB
        ensurePlayerExists(strikerName, battingTeam, "Batter")
        ensurePlayerExists(nonStrikerName, battingTeam, "Batter")
        ensurePlayerExists(bowlerName, bowlingTeam, "Bowler")

        return matchId
    }

    private suspend fun ensurePlayerExists(name: String, teamName: String, role: String) {
        if (name.isBlank()) return
        val existing = dao.getPlayerByName(name)
        if (existing == null) {
            dao.insertPlayer(PlayerEntity(name = name, teamName = teamName, role = role))
        }
    }

    suspend fun scoreBall(
        matchId: Long,
        runs: Int,
        isWide: Boolean = false,
        isNoBall: Boolean = false,
        isBye: Boolean = false,
        isLegBye: Boolean = false,
        isWicket: Boolean = false,
        wicketType: String? = null,
        dismissedPlayerName: String? = null,
        fielderName: String? = null,
        nextBatsmanName: String? = null
    ) {
        val match = dao.getMatchById(matchId) ?: return
        val inningsList = dao.getInningsForMatchFlow(matchId).first()
        val currentInnings = inningsList.firstOrNull { it.inningsNumber == match.currentInnings } ?: return

        var totalRunsAdded = runs
        var isValidBall = true

        var wideCount = currentInnings.wides
        var noBallCount = currentInnings.noBalls
        var byeCount = currentInnings.byes
        var legByeCount = currentInnings.legByes

        if (isWide) {
            totalRunsAdded += 1
            isValidBall = false
            wideCount += 1
        }
        if (isNoBall) {
            totalRunsAdded += 1
            isValidBall = false
            noBallCount += 1
        }
        if (isBye) {
            byeCount += runs
        }
        if (isLegBye) {
            legByeCount += runs
        }

        var newBallsInOver = currentInnings.ballsInCurrentOver
        var newOversCount = currentInnings.totalOversCount

        if (isValidBall) {
            newBallsInOver += 1
            if (newBallsInOver >= 6) {
                newOversCount += 1
                newBallsInOver = 0
            }
        }

        val newTotalRuns = currentInnings.totalRuns + totalRunsAdded
        val newWickets = currentInnings.totalWickets + if (isWicket) 1 else 0

        val striker = match.currentStrikerName
        val nonStriker = match.currentNonStrikerName
        val bowler = match.currentBowlerName

        // Commentary text generation
        val ballDisplayStr = "${newOversCount}.${if (isValidBall) newBallsInOver else currentInnings.ballsInCurrentOver}"
        val commentaryText = buildString {
            append("$ballDisplayStr $bowler to $striker, ")
            when {
                isWicket -> append("OUT! $wicketType! ${dismissedPlayerName ?: striker} is dismissed.")
                isWide -> append("WIDE ball ($totalRunsAdded runs total).")
                isNoBall -> append("NO BALL ($totalRunsAdded runs total).")
                runs == 4 -> append("FOUR! Brilliant shot off the bat!")
                runs == 6 -> append("SIX! Clears the boundary rope with ease!")
                runs == 0 -> append("Dot ball, well bowled.")
                else -> append("$runs run(s) taken.")
            }
        }

        val ball = BallEntity(
            matchId = matchId,
            inningsNumber = currentInnings.inningsNumber,
            overNumber = newOversCount,
            ballNumberInOver = if (isValidBall) newBallsInOver else currentInnings.ballsInCurrentOver,
            batsmanName = striker,
            bowlerName = bowler,
            runs = runs,
            isWide = isWide,
            isNoBall = isNoBall,
            isBye = isBye,
            isLegBye = isLegBye,
            isWicket = isWicket,
            wicketType = wicketType,
            dismissedPlayerName = dismissedPlayerName,
            fielderName = fielderName,
            commentary = commentaryText
        )

        dao.insertBall(ball)

        // Update Strikers
        var updatedStriker = striker
        var updatedNonStriker = nonStriker

        if (isWicket) {
            val outPlayer = dismissedPlayerName ?: striker
            if (outPlayer == striker) {
                updatedStriker = nextBatsmanName ?: "New Batsman"
            } else {
                updatedNonStriker = nextBatsmanName ?: "New Batsman"
            }
            ensurePlayerExists(updatedStriker, currentInnings.battingTeam, "Batter")
        } else {
            // Swap ends for odd runs on non-boundary or when over completes
            val runsToSwap = if (isBye || isLegBye) runs else if (!isWide && !isNoBall) runs else 0
            val shouldSwapForRuns = runsToSwap % 2 != 0
            val shouldSwapForOverEnd = isValidBall && newBallsInOver == 0

            var swap = shouldSwapForRuns
            if (shouldSwapForOverEnd) {
                swap = !swap
            }

            if (swap) {
                val temp = updatedStriker
                updatedStriker = updatedNonStriker
                updatedNonStriker = temp
            }
        }

        // Check Innings/Match Completion
        var isInningsComplete = false
        var isMatchComplete = false
        var targetRuns = match.targetRuns
        var winnerMessage = match.winnerMessage
        var nextInningsNum = match.currentInnings

        if (newWickets >= 10 || (newOversCount >= match.totalOvers && newBallsInOver == 0)) {
            isInningsComplete = true
        }

        if (match.currentInnings == 2 && targetRuns != null) {
            if (newTotalRuns >= targetRuns) {
                isInningsComplete = true
                isMatchComplete = true
                val wicketsLeft = 10 - newWickets
                winnerMessage = "${currentInnings.battingTeam} won by $wicketsLeft wickets!"
            } else if (isInningsComplete) {
                isMatchComplete = true
                val margin = (targetRuns - 1) - newTotalRuns
                winnerMessage = if (margin > 0) "${currentInnings.bowlingTeam} won by $margin runs!" else "Match Tied!"
            }
        } else if (match.currentInnings == 1 && isInningsComplete) {
            targetRuns = newTotalRuns + 1
            nextInningsNum = 2
            // Create 2nd Innings
            val secondInnings = InningsEntity(
                matchId = matchId,
                inningsNumber = 2,
                battingTeam = currentInnings.bowlingTeam,
                bowlingTeam = currentInnings.battingTeam
            )
            dao.insertInnings(secondInnings)
            
            // Default new strikers/bowlers
            updatedStriker = "Opener 1"
            updatedNonStriker = "Opener 2"
        }

        val updatedInnings = currentInnings.copy(
            totalRuns = newTotalRuns,
            totalWickets = newWickets,
            totalOversCount = newOversCount,
            ballsInCurrentOver = newBallsInOver,
            wides = wideCount,
            noBalls = noBallCount,
            byes = byeCount,
            legByes = legByeCount,
            isCompleted = isInningsComplete
        )
        dao.updateInnings(updatedInnings)

        val updatedMatch = match.copy(
            status = if (isMatchComplete) "COMPLETED" else "LIVE",
            currentInnings = nextInningsNum,
            targetRuns = targetRuns,
            winnerMessage = winnerMessage,
            currentStrikerName = updatedStriker,
            currentNonStrikerName = updatedNonStriker
        )
        dao.updateMatch(updatedMatch)

        // Update player statistics
        updatePlayerStatsAfterBall(
            batsmanName = striker,
            bowlerName = bowler,
            runs = runs,
            isWide = isWide,
            isNoBall = isNoBall,
            isBye = isBye,
            isLegBye = isLegBye,
            isWicket = isWicket,
            battingTeam = currentInnings.battingTeam,
            bowlingTeam = currentInnings.bowlingTeam
        )
    }

    private suspend fun updatePlayerStatsAfterBall(
        batsmanName: String,
        bowlerName: String,
        runs: Int,
        isWide: Boolean,
        isNoBall: Boolean,
        isBye: Boolean,
        isLegBye: Boolean,
        isWicket: Boolean,
        battingTeam: String,
        bowlingTeam: String
    ) {
        // Update Batsman
        var batter = dao.getPlayerByName(batsmanName)
        if (batter == null) {
            batter = PlayerEntity(name = batsmanName, teamName = battingTeam, role = "Batter")
        }
        val isOffBat = !isWide && !isBye && !isLegBye
        val runsToBatter = if (isOffBat) runs else 0
        val ballsFacedInc = if (!isWide) 1 else 0

        val newRunsScored = batter.runsScored + runsToBatter
        val newFours = batter.foursCount + if (isOffBat && runs == 4) 1 else 0
        val newSixes = batter.sixesCount + if (isOffBat && runs == 6) 1 else 0

        dao.insertPlayer(
            batter.copy(
                runsScored = newRunsScored,
                ballsFaced = batter.ballsFaced + ballsFacedInc,
                foursCount = newFours,
                sixesCount = newSixes,
                highestScore = maxOf(batter.highestScore, newRunsScored)
            )
        )

        // Update Bowler
        var bowl = dao.getPlayerByName(bowlerName)
        if (bowl == null) {
            bowl = PlayerEntity(name = bowlerName, teamName = bowlingTeam, role = "Bowler")
        }
        val runsConcededToBowler = if (isBye || isLegBye) 0 else (runs + (if (isWide || isNoBall) 1 else 0))
        val ballsBowledInc = if (!isWide && !isNoBall) 1 else 0

        dao.insertPlayer(
            bowl.copy(
                runsConceded = bowl.runsConceded + runsConcededToBowler,
                ballsBowled = bowl.ballsBowled + ballsBowledInc,
                wicketsTaken = bowl.wicketsTaken + if (isWicket) 1 else 0
            )
        )
    }

    suspend fun undoLastBall(matchId: Long) {
        val lastBall = dao.getLastBallForMatch(matchId) ?: return
        dao.deleteBallById(lastBall.id)

        // Recalculate current innings stats from remaining balls
        val inningsList = dao.getInningsForMatchFlow(matchId).first()
        val innings = inningsList.firstOrNull { it.inningsNumber == lastBall.inningsNumber } ?: return

        val balls = dao.getBallsForInnings(matchId, lastBall.inningsNumber)

        var totalRuns = 0
        var totalWickets = 0
        var validBalls = 0
        var wides = 0
        var noBalls = 0
        var byes = 0
        var legByes = 0

        for (b in balls) {
            var r = b.runs
            if (b.isWide) { r += 1; wides += 1 }
            if (b.isNoBall) { r += 1; noBalls += 1 }
            if (b.isBye) byes += b.runs
            if (b.isLegBye) legByes += b.runs
            if (b.isWicket) totalWickets += 1
            if (!b.isWide && !b.isNoBall) validBalls += 1
            totalRuns += r
        }

        val oversCount = validBalls / 6
        val ballsInOver = validBalls % 6

        dao.updateInnings(
            innings.copy(
                totalRuns = totalRuns,
                totalWickets = totalWickets,
                totalOversCount = oversCount,
                ballsInCurrentOver = ballsInOver,
                wides = wides,
                noBalls = noBalls,
                byes = byes,
                legByes = legByes,
                isCompleted = false
            )
        )

        val match = dao.getMatchById(matchId)
        if (match != null) {
            dao.updateMatch(match.copy(status = "LIVE", winnerMessage = null))
        }
    }

    suspend fun switchStriker(matchId: Long) {
        val match = dao.getMatchById(matchId) ?: return
        dao.updateMatch(
            match.copy(
                currentStrikerName = match.currentNonStrikerName,
                currentNonStrikerName = match.currentStrikerName
            )
        )
    }

    suspend fun changeBowler(matchId: Long, newBowlerName: String) {
        val match = dao.getMatchById(matchId) ?: return
        dao.updateMatch(match.copy(currentBowlerName = newBowlerName))
        val inningsList = dao.getInningsForMatchFlow(matchId).first()
        val currentInnings = inningsList.firstOrNull { it.inningsNumber == match.currentInnings }
        if (currentInnings != null) {
            ensurePlayerExists(newBowlerName, currentInnings.bowlingTeam, "Bowler")
        }
    }
}
