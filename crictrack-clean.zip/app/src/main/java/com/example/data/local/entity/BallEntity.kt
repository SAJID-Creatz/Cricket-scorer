package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "balls")
data class BallEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val matchId: Long,
    val inningsNumber: Int,
    val overNumber: Int, // 0-based index of over
    val ballNumberInOver: Int, // 1-based index (1 to 6+)
    val batsmanName: String,
    val bowlerName: String,
    val runs: Int = 0,
    val isWide: Boolean = false,
    val isNoBall: Boolean = false,
    val isBye: Boolean = false,
    val isLegBye: Boolean = false,
    val isWicket: Boolean = false,
    val wicketType: String? = null, // Bowled, Caught, LBW, Run Out, Stumped
    val dismissedPlayerName: String? = null,
    val fielderName: String? = null,
    val commentary: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
